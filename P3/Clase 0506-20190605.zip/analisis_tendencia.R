# Metodos Estadisticos 2019
# 
cat("\014") #Limpiar consola si lo quiero hacer sin
#funci?n uso CTL+L
rm(list=ls())
graphics.off()
print('setear directorio')
setwd("/media/usuario/datos/Nati/Docencia/Metodos_estadisticos/2019/Clases_Practicas/Clase_Filtros/") 


######ajuste tendencia y restar tendencia en R


datostemperatura<-read.table('datos_temperatura.txt')
#hago el ajuste en funcion del tiempo 
ajuste1<-lm(temperatura~meses,data=datostemperatura)
summary(ajuste1)
ajuste1$coefficients


plot(datostemperatura$meses,datostemperatura$temperatura,type='l')
abline(ajuste1,col='red',lwd=2)
ajuste1$fitted.values


tendencia<-ajuste1$coefficients[1]+ajuste1$coefficients[2]*datostemperatura$meses

#como filtramos la tendencia??? me puedo quedar alrededor del 0
#o en valroes a los de mi variable

datosf<-datostemperatura$temperatura - tendencia
plot(ts(datosf))

datosff<-datostemperatura$temperatura - (ajuste1$coefficients[2]*datostemperatura$meses)
plot(ts(datosff))


